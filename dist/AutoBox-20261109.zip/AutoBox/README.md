# AutoBox 按键循环

Windows 桌面小工具：游戏在前台时循环发送“主键盘数字 1–5 中的一个键 → 空格”。切到其他软件后自动暂停，切回游戏后继续。无需安装 Python、AutoHotkey 或额外下载依赖。

本版已取消后台消息发送，改为 Windows `SendInput` 扫描码模拟输入。**尚未验证 DNF 客户端是否接收这种输入，不能保证游戏响应。** 程序不会主动切换到游戏。每次按下前会检查目标是否在前台；若切换窗口时有本工具按住的键，仍会发送对应的松开操作，避免按键一直保持按下。

## 使用

1. 双击 `dist/AutoBox.exe`，在 Windows 管理员权限提示中选择“是”。解压发行包时，直接双击包内的 `AutoBox.exe`。程序默认请求管理员权限，标题栏会显示当前权限状态。
2. 点击“刷新窗口”，选择 DNF 对应的窗口。若游戏已重启，需要重新选择。
3. 设置操作键和三个时间，单位均为毫秒，1000 毫秒 = 1 秒。
4. 切回游戏，按 **F8** 开始。也可以点击“开始循环”后切回游戏；状态栏在游戏不处于前台时显示暂停。
5. 按 **F9** 只停止；**F8** 切换开始 / 停止。两个快捷键可在界面修改，运行时在其他软件中也会被本工具占用。若显示快捷键冲突，请换一个键或使用按钮。
6. 最小化进入系统托盘；双击托盘图标恢复窗口，右键可以停止或退出。关闭窗口会先停止循环再退出。

程序启动后不会自动发送按键。运行中锁定配置，停止后可修改。默认自定义键为主键盘数字 **1**，每个键按住 **50 ms**，1 松开后等 **200 ms** 按空格，空格松开后等 **1000 ms** 进入下一轮。因此默认一轮约 **1300 ms**，实际调度会有误差。旧配置中不再支持的操作键会自动回退为 1。

可配置范围：按住时间 10–5000 ms，动作间隔 0–600000 ms，循环间隔 10–3600000 ms。操作键仅可选择 QWER 上方的主键盘数字 **1、2、3、4、5**，不是小键盘数字；其余操作键选项已删除。每次操作键之后仍固定按空格。全局开始 / 停止快捷键仍可选择 F1–F12。

参数保存在 `%LOCALAPPDATA%\AutoBox\settings.xml`。下次启动会恢复参数和优先选择上次的进程，但不会自动开始循环。

## DNF 输入验证

先将循环间隔调到 2000 ms，选择一个已在游戏中绑定、容易观察效果的数字键，保持游戏在前台，按 F8 启动，观察是否执行动作，然后按 F9 停止。切换到其他软件时应暂停，返回游戏时继续。

管理员权限用于减少进程权限差异导致的发送失败。如果游戏在前台仍无反应，可能不接受模拟输入；提升权限和调整时间均不能保证解决此问题。

## 开发与验证

源码使用 C# / Windows Forms，面向 Windows 内置 .NET Framework 4.x（需要 4.5 或更高版本；建议 Windows 10/11）。开发构建无需安装 .NET SDK。

在 Windows PowerShell 中运行：

```powershell
.\build.ps1
.\build.ps1 -Test
```

如本机策略不允许运行脚本，可双击 `build.cmd`，或运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1 -Test
```

测试覆盖循环顺序、停止与按键释放、释放失败、参数范围、目标窗口身份、窗口关闭、前台判断、切换窗口后暂停和恢复，以及按下前再次检查焦点。焦点切换测试使用模拟输入后端，不会向 DNF 发送测试按键；测试通过不代表已验证 DNF 的兼容性。

相关平台文档：

- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-keybdinput
- https://learn.microsoft.com/en-us/windows/win32/sbscs/application-manifests
- https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-registerhotkey
